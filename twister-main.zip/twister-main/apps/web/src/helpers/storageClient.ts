import { StorageClient } from "@lens-chain/storage-client";

export const storageClient = StorageClient.create();
