import { cors as corsMiddleware } from "hono/cors";

const allowedOrigins = [
  "https://twister.xyz",
  "https://testnet.twister.xyz",
  "https://staging.twister.xyz",
  "http://localhost:4783",
  "https://developer.lens.xyz"
];

const cors = corsMiddleware({
  allowHeaders: ["Content-Type", "X-Access-Token"],
  allowMethods: ["GET", "POST", "OPTIONS"],
  credentials: true,
  origin: allowedOrigins
});

export default cors;
